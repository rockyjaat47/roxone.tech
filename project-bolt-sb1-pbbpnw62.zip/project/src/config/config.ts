export const config = {
  // Gemini configuration
  GEMINI_API_KEY: 'AIzaSyDWwhpXNKEvvyJsIJQrBCdXE2V_22pwyGA',
  GEMINI_API_URL: 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent',
  GEMINI_MODEL: 'gemini-pro',
  
  // Fallback configuration
  USE_FALLBACK: true,
  MAX_RETRIES: 3,
  TIMEOUT: 30000
};