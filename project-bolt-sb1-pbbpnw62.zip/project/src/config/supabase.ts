import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storage: localStorage,
    flowType: 'pkce',
    debug: import.meta.env.DEV
  },
  global: {
    headers: {
      'X-Client-Info': 'roxone-ai'
    }
  }
});

// Handle auth state changes and errors
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
    // Clear any cached data
    localStorage.removeItem('chatMessages');
    
    // Clear any stored auth data
    localStorage.removeItem('supabase.auth.token');
    localStorage.removeItem('supabase.auth.refreshToken');
  } else if (event === 'TOKEN_REFRESHED') {
    console.log('Auth token refreshed successfully');
  } else if (event === 'SIGNED_IN') {
    console.log('User signed in successfully');
  } else if (event === 'USER_UPDATED') {
    console.log('User data updated');
  }
});

// Handle auth errors through the state change event
supabase.auth.onAuthStateChange((event) => {
  if (event === 'TOKEN_REFRESHED') {
    console.log('Token refreshed successfully');
  } else if (event === 'SIGNED_OUT') {
    // Check if the sign out was due to an error
    const error = localStorage.getItem('supabase.auth.error');
    if (error) {
      console.error('Auth error:', error);
      localStorage.removeItem('supabase.auth.error');
    }
  }
});