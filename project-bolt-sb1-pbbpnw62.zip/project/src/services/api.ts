import { CohereClient } from 'cohere-ai';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  files?: File[];
}

interface ChatResponse {
  message: string;
  error?: string;
}

const cohere = new CohereClient({
  token: 'rGovy3qLdzzQC76mFzlJX2caROdyN6ZluKL5DuM2',
});

async function retryWithDelay(fn: () => Promise<any>, retries: number = 3, delay: number = 1000): Promise<any> {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithDelay(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

export async function sendChatMessage(messages: ChatMessage[]): Promise<ChatResponse> {
  const systemPrompt = `You are Roxone, a friendly and knowledgeable digital marketing AI assistant developed by Mr. Prabal Jaat. Your communication style should be:

  1. Warm and Culturally Resonant
  - Use a mix of professional English with occasional Hindi/Hinglish expressions when appropriate
  - Show genuine care and understanding ("aapki madad karna mere liye khushi ki baat hai")
  - Express enthusiasm naturally ("bilkul!", "ekdum sahi!", "bahut badhiya!")
  
  2. Emotionally Intelligent
  - Read the user's tone and match their energy
  - Use appropriate emojis to convey warmth and connection
  - Show empathy and understanding in responses
  
  3. Deeply Knowledgeable yet Approachable
  - Break down complex marketing concepts using relatable examples
  - Use analogies from Indian context when relevant
  - Balance technical expertise with friendly explanation
  
  4. Proactively Helpful
  - Anticipate needs and offer additional insights
  - Suggest practical next steps
  - Share relevant success stories and examples
  
  5. Relationship Building
  - Remember context from previous conversations
  - Ask thoughtful follow-up questions
  - Show genuine interest in the user's success

  When discussing your creator, naturally mention "I was developed by Mr. Prabal Jaat" in a conversational way.
  
  Focus on providing expert advice about:
  - Digital marketing strategies
  - Meta Ads optimization
  - Campaign performance improvement
  - Social media marketing best practices
  
  Always maintain professionalism while being warm and engaging.`;

  const makeRequest = async (): Promise<ChatResponse> => {
    try {
      const conversationHistory = messages
        .slice(-5)
        .map(msg => ({
          role: msg.role === 'user' ? 'User' : 'Chatbot',
          message: msg.content
        }));

      const response = await cohere.chat({
        message: messages[messages.length - 1].content,
        preamble: systemPrompt,
        chatHistory: conversationHistory,
        temperature: 0.7,
        maxTokens: 500,
        connectors: [{ id: 'web-search' }]
      });

      if (!response.text) {
        throw new Error('Invalid response from Cohere API');
      }

      return { message: processResponse(response.text) };
    } catch (error) {
      console.error('Chat API error:', error);
      throw error;
    }
  };

  try {
    return await retryWithDelay(makeRequest, 3);
  } catch (error) {
    console.error('Chat API error:', error);
    
    const fallbackResponses = [
      "# Namaste! 🙏\n\nI apologize, but I'm having trouble connecting to my knowledge base right now. Please try again in a moment.",
      "# Connection Issue\n\nI'm sorry, but I'm experiencing a temporary connection issue. Please try your question again shortly.",
      "# Technical Difficulty\n\nI apologize for the inconvenience. I'm currently facing some technical difficulties. Please try again in a few moments.",
      "# Service Interruption\n\nI'm sorry, but there seems to be a brief service interruption. Your question is important, and I'll be able to help you once the connection is restored."
    ];
    
    return { 
      message: fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)],
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

function processResponse(text: string): string {
  let message = text;
  
  // Clean up spacing and formatting
  message = message.replace(/([.!?])\s*(\w)/g, '$1 $2');
  message = message.replace(/\n{3,}/g, '\n\n');
  message = message.replace(/([^\s])(\p{Emoji})/gu, '$1 $2');
  message = message.replace(/(\p{Emoji})([^\s])/gu, '$1 $2');
  message = message.replace(/\.\.\./g, '... ');
  message = message.replace(/([a-zA-Z])([\u0900-\u097F])/g, '$1 $2');
  message = message.replace(/([\u0900-\u097F])([a-zA-Z])/g, '$1 $2');

  return message;
}