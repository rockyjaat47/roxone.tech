import React from 'react';
import { X, Shield, Zap, User, Check } from 'lucide-react';

interface ChangelogProps {
  onClose: () => void;
}

function Changelog({ onClose }: ChangelogProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-bg-primary rounded-2xl shadow-xl w-full max-w-md mx-4 p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-text-secondary hover:text-text-primary transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
        <h2 className="text-2xl font-bold text-primary mb-6">What's New in Version 2.1</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-3 text-text-primary flex items-center gap-2">
              <User className="w-5 h-5 text-primary" />
              Enhanced Authentication
            </h3>
            <ul className="space-y-2 text-text-secondary">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Improved sign-up and login experience
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                New user profile dropdown menu
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Seamless sign-out functionality
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Profile picture support with fallback avatars
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3 text-text-primary flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Security Improvements
            </h3>
            <ul className="space-y-2 text-text-secondary">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Enhanced error handling and validation
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Improved session management
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Secure authentication flow
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3 text-text-primary flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              User Experience Updates
            </h3>
            <ul className="space-y-2 text-text-secondary">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Success messages for better feedback
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Improved mobile responsiveness
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Enhanced UI animations and transitions
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                Better error messaging and handling
              </li>
            </ul>
          </div>
        </div>
        <button
          onClick={onClose}
          className="mt-6 w-full btn-material btn-material-primary"
        >
          Got it!
        </button>
      </div>
    </div>
  );
}

export default Changelog;