import React from 'react';
import { Upload, X } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

interface FileUploadProps {
  onFileSelect: (files: File[]) => void;
  isUploading: boolean;
}

function FileUpload({ onFileSelect, isUploading }: FileUploadProps) {
  const { getRootProps, getInputProps, isDragActive, acceptedFiles } = useDropzone({
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
    },
    onDrop: onFileSelect,
    disabled: isUploading,
    maxSize: 5242880, // 5MB
  });

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-3 transition-colors cursor-pointer
        ${isDragActive ? 'border-primary bg-primary/10' : 'border-text-secondary hover:border-primary'}
        ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-2 text-xs sm:text-sm text-text-secondary">
        <Upload className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
        <p className="text-center">
          {isDragActive
            ? 'Drop files here...'
            : 'Tap to upload or drop files here'}
        </p>
        <p className="text-xs opacity-75">
          Max size: 5MB • Images, PDFs, Text
        </p>
      </div>
    </div>
  );
}

export default FileUpload;